"""
ApexTweak v2.0 — Professional PC Performance Optimizer
Blue/Black Snow UI | Owner Mode | 30+ Tweaks | Multiple Themes | Advanced Monitoring
"""

import tkinter as tk
from tkinter import ttk, messagebox
import customtkinter as ctk
import threading
import subprocess
import os
import sys
import json
import random
import math
import time
import platform
import psutil
from PIL import Image, ImageTk
from datetime import datetime

# ─── Theme Definitions ────────────────────────────────────────────────────────
THEMES = {
    "dark": {
        "bg_dark": "#050A14",
        "bg_mid": "#0A1628",
        "bg_card": "#0D1F3C",
        "blue_neon": "#00AAFF",
        "blue_dim": "#0066CC",
        "blue_glow": "#33CCFF",
        "white": "#FFFFFF",
        "gray": "#8899AA",
        "green": "#00FF88",
        "red": "#FF4455",
        "gold": "#FFD700",
    },
    "neon": {
        "bg_dark": "#0a0e27",
        "bg_mid": "#1a1f3a",
        "bg_card": "#2d1b4e",
        "blue_neon": "#FF006E",
        "blue_dim": "#8338EC",
        "blue_glow": "#FB5607",
        "white": "#FFFFFF",
        "gray": "#B0B0B0",
        "green": "#00FF88",
        "red": "#FF4455",
        "gold": "#FFBE0B",
    },
    "matrix": {
        "bg_dark": "#000000",
        "bg_mid": "#0d0d0d",
        "bg_card": "#1a1a1a",
        "blue_neon": "#00FF41",
        "blue_dim": "#00AA22",
        "blue_glow": "#00FF88",
        "white": "#00FF41",
        "gray": "#00AA22",
        "green": "#00FF41",
        "red": "#FF0000",
        "gold": "#FFFF00",
    },
    "cyberpunk": {
        "bg_dark": "#0f0f1e",
        "bg_mid": "#1a1a2e",
        "bg_card": "#16213e",
        "blue_neon": "#00d9ff",
        "blue_dim": "#0099cc",
        "blue_glow": "#00ffff",
        "white": "#e0e0e0",
        "gray": "#888899",
        "green": "#00ff88",
        "red": "#ff0055",
        "gold": "#ffaa00",
    },
}

# ─── Paths ────────────────────────────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
KEYS_FILE = os.path.join(BASE_DIR, "..", "keys", "valid_keys.txt")
STATE_FILE = os.path.join(BASE_DIR, "state.json")
LOGO_FILE = os.path.join(BASE_DIR, "logo.png")
OWNER_MODE_FILE = os.path.join(BASE_DIR, ".owner")

# ─── Owner Mode Check ─────────────────────────────────────────────────────────
def is_owner():
    return os.path.exists(OWNER_MODE_FILE)

def enable_owner_mode():
    with open(OWNER_MODE_FILE, "w") as f:
        f.write("OWNER_MODE_ENABLED")

# ─── Tweaks Library (30+) ─────────────────────────────────────────────────────
IS_WINDOWS = platform.system() == "Windows"

def run_cmd(cmd, shell=True):
    try:
        subprocess.run(cmd, shell=shell, capture_output=True, timeout=15)
        return True
    except Exception:
        return False

# ── FPS & Gaming Tweaks ────────────────────────────────────────────────────────
def tweak_disable_xbox_dvr():
    if IS_WINDOWS:
        run_cmd('reg add "HKCU\\System\\GameConfigStore" /v GameDVR_Enabled /t REG_DWORD /d 0 /f')
        run_cmd('reg add "HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\GameDVR" /v AllowGameDVR /t REG_DWORD /d 0 /f')
    return True, "Xbox Game DVR disabled — FPS boost applied."

def tweak_gpu_hardware_scheduling():
    if IS_WINDOWS:
        run_cmd('reg add "HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers" /v HwSchMode /t REG_DWORD /d 2 /f')
    return True, "GPU hardware scheduling enabled — smoother frames."

def tweak_ultimate_perf_plan():
    if IS_WINDOWS:
        run_cmd("powercfg -duplicatescheme e9a42b02-d5df-448d-aa00-03f14749eb61")
        run_cmd("powercfg /setactive e9a42b02-d5df-448d-aa00-03f14749eb61")
    return True, "Ultimate Performance plan activated."

def tweak_disable_core_parking():
    if IS_WINDOWS:
        run_cmd('reg add "HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power\\PowerSettings\\54533251-82be-4824-96c1-47b60b740d00\\0cc5b647-c1df-4637-891a-dec35c318583" /v ValueMax /t REG_DWORD /d 0 /f')
    return True, "CPU core parking disabled — all cores active."

def tweak_boost_game_priority():
    if IS_WINDOWS:
        run_cmd('reg add "HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games" /v "GPU Priority" /t REG_DWORD /d 8 /f')
        run_cmd('reg add "HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games" /v Priority /t REG_DWORD /d 6 /f')
    return True, "Game CPU & GPU priority boosted."

def tweak_disable_fullscreen_optimizations():
    if IS_WINDOWS:
        run_cmd('reg add "HKCU\\System\\GameConfigStore" /v GameDVR_FSEBehaviorMonitoringEnabled /t REG_DWORD /d 0 /f')
    return True, "Fullscreen optimizations disabled."

def tweak_increase_gpu_memory():
    if IS_WINDOWS:
        run_cmd('reg add "HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile" /v NetworkThrottlingIndex /t REG_DWORD /d 10 /f')
    return True, "GPU memory allocation optimized."

# ── CPU & Process Tweaks ───────────────────────────────────────────────────────
def tweak_disable_telemetry():
    if IS_WINDOWS:
        run_cmd('sc stop DiagTrack')
        run_cmd('sc config DiagTrack start=disabled')
        run_cmd('reg add "HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\DataCollection" /v AllowTelemetry /t REG_DWORD /d 0 /f')
    return True, "Windows telemetry disabled — CPU freed."

def tweak_disable_search_indexing():
    if IS_WINDOWS:
        run_cmd("sc stop WSearch")
        run_cmd("sc config WSearch start=disabled")
    return True, "Windows Search disabled — disk & CPU freed."

def tweak_disable_superfetch():
    if IS_WINDOWS:
        run_cmd("sc stop SysMain")
        run_cmd("sc config SysMain start=disabled")
    return True, "SysMain (Superfetch) disabled — RAM freed."

def tweak_disable_background_apps():
    if IS_WINDOWS:
        run_cmd('reg add "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\BackgroundAccessApplications" /v GlobalUserDisabled /t REG_DWORD /d 1 /f')
    return True, "Background UWP apps disabled."

def tweak_optimize_ram():
    if IS_WINDOWS:
        run_cmd('reg add "HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management" /v DisablePagingExecutive /t REG_DWORD /d 1 /f')
    return True, "RAM management optimized."

def tweak_disable_startup_delay():
    if IS_WINDOWS:
        run_cmd('reg add "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Serialize" /v StartupDelayInMSec /t REG_DWORD /d 0 /f')
    return True, "Startup delay removed — faster boot."

def tweak_disable_animations():
    if IS_WINDOWS:
        run_cmd('reg add "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\VisualEffects" /v VisualFXSetting /t REG_DWORD /d 2 /f')
    return True, "Windows animations disabled."

def tweak_disable_transparency():
    if IS_WINDOWS:
        run_cmd('reg add "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize" /v EnableTransparency /t REG_DWORD /d 0 /f')
    return True, "Transparency effects disabled."

def tweak_disable_tips_notifications():
    if IS_WINDOWS:
        run_cmd('reg add "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\ContentDeliveryManager" /v SoftLandingEnabled /t REG_DWORD /d 0 /f')
    return True, "Tips and notifications disabled."

# ── Network Tweaks ────────────────────────────────────────────────────────────
def tweak_disable_nagle():
    if IS_WINDOWS:
        run_cmd('reg add "HKLM\\SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters" /v TCPNoDelay /t REG_DWORD /d 1 /f')
    return True, "Nagle's algorithm disabled — lower ping."

def tweak_optimize_network():
    if IS_WINDOWS:
        run_cmd("netsh int tcp set global autotuninglevel=normal")
        run_cmd("netsh int tcp set global congestionprovider=ctcp")
        run_cmd("netsh int tcp set global ecncapability=enabled")
        run_cmd("netsh int tcp set global fastopen=enabled")
    return True, "Network stack optimized."

def tweak_tcp_optimizer():
    if IS_WINDOWS:
        run_cmd("netsh int tcp set global initialRto=2000")
        run_cmd("netsh int tcp set global minRto=300")
        run_cmd("netsh int tcp set heuristics disabled")
    return True, "TCP stack tuned for low ping."

def tweak_disable_ipv6():
    if IS_WINDOWS:
        run_cmd('reg add "HKLM\\SYSTEM\\CurrentControlSet\\Services\\Tcpip6\\Parameters" /v DisabledComponents /t REG_DWORD /d 255 /f')
    return True, "IPv6 disabled — IPv4 prioritized."

def tweak_enable_rss():
    if IS_WINDOWS:
        run_cmd("netsh int tcp set global rss=enabled")
    return True, "RSS (Receive Side Scaling) enabled."

# ── Cleaning Tweaks ───────────────────────────────────────────────────────────
def tweak_clear_temp():
    if IS_WINDOWS:
        run_cmd("del /q/f/s %TEMP%\\*")
        run_cmd("del /q/f/s C:\\Windows\\Temp\\*")
    return True, "Temp files cleared."

def tweak_flush_dns():
    if IS_WINDOWS:
        run_cmd("ipconfig /flushdns")
    return True, "DNS cache flushed."

def tweak_clear_prefetch():
    if IS_WINDOWS:
        run_cmd("del /q/f/s C:\\Windows\\Prefetch\\*")
    return True, "Prefetch cache cleared."

def tweak_clear_event_logs():
    if IS_WINDOWS:
        run_cmd("for /F \"tokens=*\" %1 in ('wevtutil.exe el') do wevtutil.exe cl \"%1\"')
    return True, "Event logs cleared."

# ── Input & Mouse Tweaks ──────────────────────────────────────────────────────
def tweak_zero_delay_mouse():
    if IS_WINDOWS:
        run_cmd('reg add "HKCU\\Control Panel\\Mouse" /v MouseSpeed /t REG_SZ /d 0 /f')
        run_cmd('reg add "HKCU\\Control Panel\\Mouse" /v MouseThreshold1 /t REG_SZ /d 0 /f')
        run_cmd('reg add "HKCU\\Control Panel\\Mouse" /v MouseThreshold2 /t REG_SZ /d 0 /f')
    return True, "Zero mouse delay applied — raw 1:1 input."

def tweak_disable_mouse_acceleration():
    if IS_WINDOWS:
        run_cmd('reg add "HKCU\\Control Panel\\Mouse" /v MouseSpeed /t REG_SZ /d 0 /f')
    return True, "Mouse acceleration disabled."

# ── Advanced Tweaks ───────────────────────────────────────────────────────────
def tweak_power_high_perf():
    if IS_WINDOWS:
        run_cmd("powercfg /setactive 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c")
    return True, "High Performance power plan set."

def tweak_disable_usb_selective_suspend():
    if IS_WINDOWS:
        run_cmd('reg add "HKLM\\SYSTEM\\CurrentControlSet\\Services\\usbhub\\Parameters" /v DisableSelectiveSuspend /t REG_DWORD /d 1 /f')
    return True, "USB selective suspend disabled."

def tweak_increase_file_cache():
    if IS_WINDOWS:
        run_cmd('reg add "HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management" /v LargeSystemCache /t REG_DWORD /d 1 /f')
    return True, "File cache increased."

def tweak_disable_fast_startup():
    if IS_WINDOWS:
        run_cmd('reg add "HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Power" /v HibernateEnabled /t REG_DWORD /d 0 /f')
    return True, "Fast startup disabled (full shutdown)."

def tweak_optimize_ssd():
    if IS_WINDOWS:
        run_cmd("fsutil behavior set DisableLastAccess 1")
    return True, "SSD optimization enabled."

def tweak_disable_paging_file():
    if IS_WINDOWS:
        run_cmd('reg add "HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management" /v PagingFiles /t REG_MULTI_SZ /d "" /f')
    return True, "Paging file disabled (requires RAM)."

# ── Tweak Dispatcher ──────────────────────────────────────────────────────────
TWEAKS = {
    # FPS & Gaming
    "disable_xbox_dvr": ("🎮 Disable Xbox Game DVR", tweak_disable_xbox_dvr, "fps"),
    "gpu_hardware_scheduling": ("🖥️ GPU Hardware Scheduling", tweak_gpu_hardware_scheduling, "fps"),
    "ultimate_perf_plan": ("⚡ Ultimate Performance Plan", tweak_ultimate_perf_plan, "fps"),
    "disable_core_parking": ("🔥 Disable CPU Core Parking", tweak_disable_core_parking, "fps"),
    "boost_game_priority": ("🎯 Boost Game Priority", tweak_boost_game_priority, "fps"),
    "disable_fullscreen_optimizations": ("🖼️ Disable Fullscreen Optimizations", tweak_disable_fullscreen_optimizations, "fps"),
    "increase_gpu_memory": ("💾 Increase GPU Memory", tweak_increase_gpu_memory, "fps"),
    
    # CPU & Process
    "disable_telemetry": ("📡 Disable Telemetry", tweak_disable_telemetry, "cpu"),
    "disable_search_indexing": ("🔍 Disable Search Indexing", tweak_disable_search_indexing, "cpu"),
    "disable_superfetch": ("⚙️ Disable Superfetch", tweak_disable_superfetch, "cpu"),
    "disable_background_apps": ("🚫 Disable Background Apps", tweak_disable_background_apps, "cpu"),
    "optimize_ram": ("🧠 Optimize RAM", tweak_optimize_ram, "cpu"),
    "disable_startup_delay": ("⏱️ Remove Startup Delay", tweak_disable_startup_delay, "cpu"),
    "disable_animations": ("✨ Disable Animations", tweak_disable_animations, "cpu"),
    "disable_transparency": ("👁️ Disable Transparency", tweak_disable_transparency, "cpu"),
    "disable_tips_notifications": ("🔔 Disable Tips & Notifications", tweak_disable_tips_notifications, "cpu"),
    
    # Network
    "disable_nagle": ("🌐 Disable Nagle's Algorithm", tweak_disable_nagle, "network"),
    "optimize_network": ("📊 Full Network Optimization", tweak_optimize_network, "network"),
    "tcp_optimizer": ("🔗 TCP Stack Optimizer", tweak_tcp_optimizer, "network"),
    "disable_ipv6": ("📮 Disable IPv6", tweak_disable_ipv6, "network"),
    "enable_rss": ("📈 Enable RSS", tweak_enable_rss, "network"),
    
    # Cleaning
    "clear_temp": ("🧹 Clear Temp Files", tweak_clear_temp, "clean"),
    "flush_dns": ("🌊 Flush DNS Cache", tweak_flush_dns, "clean"),
    "clear_prefetch": ("📋 Clear Prefetch", tweak_clear_prefetch, "clean"),
    "clear_event_logs": ("📜 Clear Event Logs", tweak_clear_event_logs, "clean"),
    
    # Input & Mouse
    "zero_delay_mouse": ("🖱️ Zero Delay Mouse", tweak_zero_delay_mouse, "input"),
    "disable_mouse_acceleration": ("🎮 Disable Mouse Acceleration", tweak_disable_mouse_acceleration, "input"),
    
    # Advanced
    "power_high_perf": ("⚡ High Performance Plan", tweak_power_high_perf, "advanced"),
    "disable_usb_selective_suspend": ("🔌 Disable USB Suspend", tweak_disable_usb_selective_suspend, "advanced"),
    "increase_file_cache": ("📁 Increase File Cache", tweak_increase_file_cache, "advanced"),
    "disable_fast_startup": ("🔄 Disable Fast Startup", tweak_disable_fast_startup, "advanced"),
    "optimize_ssd": ("💿 Optimize SSD", tweak_optimize_ssd, "advanced"),
}

def apply_tweak(key):
    if key in TWEAKS:
        _, func, _ = TWEAKS[key]
        return func()
    return False, "Unknown tweak."

# ─── Snow Canvas ──────────────────────────────────────────────────────────────
class SnowCanvas(tk.Canvas):
    def __init__(self, master, theme_colors, **kwargs):
        super().__init__(master, bg=theme_colors["bg_dark"], highlightthickness=0, **kwargs)
        self.theme_colors = theme_colors
        self.flakes = []
        self._init_flakes()
        self._animate()

    def _init_flakes(self):
        w = self.winfo_reqwidth() or 1200
        h = self.winfo_reqheight() or 800
        for _ in range(120):
            x = random.uniform(0, w)
            y = random.uniform(0, h)
            r = random.uniform(1, 3.5)
            speed = random.uniform(0.4, 1.4)
            drift = random.uniform(-0.3, 0.3)
            alpha = random.randint(80, 200)
            self.flakes.append([x, y, r, speed, drift, alpha])

    def _animate(self):
        self.delete("snow")
        w = self.winfo_width() or 1200
        h = self.winfo_height() or 800
        for f in self.flakes:
            x, y, r, speed, drift, alpha = f
            color = self.theme_colors["blue_glow"]
            self.create_oval(x-r, y-r, x+r, y+r, fill=color, outline="", tags="snow")
            f[0] += drift
            f[1] += speed
            if f[1] > h:
                f[1] = -5
                f[0] = random.uniform(0, w)
            if f[0] < 0: f[0] = w
            if f[0] > w: f[0] = 0
        self.after(30, self._animate)

# ─── Main Application ─────────────────────────────────────────────────────────
class ApexTweakV2(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.current_theme = "dark"
        self.theme_colors = THEMES[self.current_theme]
        self.is_owner = is_owner()
        
        self.title("ApexTweak v2.0 — PC Performance Optimizer")
        self.geometry("1200x800")
        self.minsize(1000, 700)
        self.configure(fg_color=self.theme_colors["bg_dark"])

        self._load_logo()
        self._build_ui()

    def _load_logo(self):
        try:
            img = Image.open(LOGO_FILE).resize((120, 120))
            self.logo_img = ImageTk.PhotoImage(img)
        except Exception:
            self.logo_img = None

    def _build_ui(self):
        # ── Sidebar ───────────────────────────────────────────────────────────
        self.sidebar = ctk.CTkFrame(self, width=200, fg_color=self.theme_colors["bg_mid"], corner_radius=0)
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)

        if self.logo_img:
            logo_lbl = tk.Label(self.sidebar, image=self.logo_img, bg=self.theme_colors["bg_mid"])
            logo_lbl.pack(pady=(12, 4))

        ctk.CTkLabel(self.sidebar, text="ApexTweak v2.0", font=("Segoe UI", 16, "bold"),
                     text_color=self.theme_colors["blue_neon"]).pack(pady=(0, 2))

        owner_text = "👑 OWNER MODE" if self.is_owner else "🔓 USER MODE"
        ctk.CTkLabel(self.sidebar, text=owner_text, font=("Segoe UI", 9, "bold"),
                     text_color=self.theme_colors["gold"] if self.is_owner else self.theme_colors["gray"]).pack(pady=(0, 12))

        sep = ctk.CTkFrame(self.sidebar, height=1, fg_color=self.theme_colors["blue_dim"])
        sep.pack(fill="x", padx=12, pady=4)

        nav_items = [
            ("🏠 Dashboard", "dashboard"),
            ("🚀 FPS Boost", "fps"),
            ("⚙️ CPU & Process", "cpu"),
            ("🌐 Network", "network"),
            ("🧹 Cleaner", "clean"),
            ("🖱️ Input & Mouse", "input"),
            ("🔧 Advanced", "advanced"),
            ("👑 Owner Panel", "owner") if self.is_owner else None,
            ("🎨 Themes", "themes"),
            ("ℹ️ About", "about"),
        ]

        self.nav_buttons = {}
        for item in nav_items:
            if item is None:
                continue
            label, key = item
            btn = ctk.CTkButton(
                self.sidebar, text=label, anchor="w",
                fg_color="transparent", hover_color=self.theme_colors["bg_card"],
                text_color=self.theme_colors["white"], font=("Segoe UI", 11),
                corner_radius=6, height=36,
                command=lambda k=key: self._show_page(k)
            )
            btn.pack(fill="x", padx=8, pady=2)
            self.nav_buttons[key] = btn

        # Stats
        ctk.CTkFrame(self.sidebar, height=1, fg_color=self.theme_colors["blue_dim"]).pack(fill="x", padx=12, pady=(12, 4))
        self.cpu_lbl = ctk.CTkLabel(self.sidebar, text="CPU: --", font=("Consolas", 10), text_color=self.theme_colors["blue_glow"])
        self.cpu_lbl.pack(anchor="w", padx=12)
        self.ram_lbl = ctk.CTkLabel(self.sidebar, text="RAM: --", font=("Consolas", 10), text_color=self.theme_colors["blue_glow"])
        self.ram_lbl.pack(anchor="w", padx=12, pady=(0, 10))

        # ── Main Content ──────────────────────────────────────────────────────
        self.content = ctk.CTkFrame(self, fg_color=self.theme_colors["bg_dark"], corner_radius=0)
        self.content.pack(side="left", fill="both", expand=True)

        self.snow = SnowCanvas(self.content, self.theme_colors, width=1000, height=800)
        self.snow.place(x=0, y=0, relwidth=1, relheight=1)

        self.page_frame = ctk.CTkFrame(self.content, fg_color="transparent")
        self.page_frame.place(x=0, y=0, relwidth=1, relheight=1)

        self._show_page("dashboard")
        self._start_stats_loop()

    def _show_page(self, key):
        for w in self.page_frame.winfo_children():
            w.destroy()
        for k, btn in self.nav_buttons.items():
            btn.configure(fg_color=self.theme_colors["bg_card"] if k == key else "transparent")

        pages = {
            "dashboard": self._page_dashboard,
            "fps": lambda: self._page_category("🚀 FPS Boost", "fps"),
            "cpu": lambda: self._page_category("⚙️ CPU & Process", "cpu"),
            "network": lambda: self._page_category("🌐 Network", "network"),
            "clean": lambda: self._page_category("🧹 Cleaner", "clean"),
            "input": lambda: self._page_category("🖱️ Input & Mouse", "input"),
            "advanced": lambda: self._page_category("🔧 Advanced", "advanced"),
            "owner": self._page_owner if self.is_owner else None,
            "themes": self._page_themes,
            "about": self._page_about,
        }
        if pages.get(key):
            pages[key]()

    def _page_dashboard(self):
        f = self.page_frame
        ctk.CTkLabel(f, text="ApexTweak v2.0", font=("Segoe UI", 28, "bold"),
                     text_color=self.theme_colors["blue_neon"]).pack(pady=(30, 4))
        ctk.CTkLabel(f, text="Professional PC Performance Optimizer",
                     font=("Segoe UI", 12), text_color=self.theme_colors["gray"]).pack(pady=(0, 20))

        info_box = ctk.CTkFrame(f, fg_color=self.theme_colors["bg_card"], corner_radius=12)
        info_box.pack(pady=10, padx=40, fill="x")
        ctk.CTkLabel(info_box, text="✨ 30+ Professional Tweaks | 5 Categories | Multiple Themes | Owner Mode",
                     font=("Segoe UI", 11), text_color=self.theme_colors["white"]).pack(pady=12, padx=20)

    def _page_category(self, title, category):
        f = self.page_frame
        ctk.CTkLabel(f, text=title, font=("Segoe UI", 22, "bold"),
                     text_color=self.theme_colors["blue_neon"]).pack(pady=(20, 10), padx=20, anchor="w")

        scroll = ctk.CTkScrollableFrame(f, fg_color="transparent")
        scroll.pack(fill="both", expand=True, padx=20, pady=10)

        tweaks_in_cat = [(k, v) for k, v in TWEAKS.items() if v[2] == category]
        for key, (name, _, _) in tweaks_in_cat:
            card = ctk.CTkFrame(scroll, fg_color=self.theme_colors["bg_card"], corner_radius=10)
            card.pack(fill="x", pady=4, padx=4)

            info = ctk.CTkFrame(card, fg_color="transparent")
            info.pack(side="left", fill="both", expand=True, padx=12, pady=10)

            ctk.CTkLabel(info, text=name, font=("Segoe UI", 12, "bold"),
                         text_color=self.theme_colors["white"]).pack(anchor="w")

            btn = ctk.CTkButton(
                card, text="Apply",
                fg_color=self.theme_colors["blue_dim"],
                hover_color=self.theme_colors["blue_neon"],
                text_color=self.theme_colors["white"],
                font=("Segoe UI", 11, "bold"), width=80, height=32, corner_radius=6,
                command=lambda k=key: self._run_tweak(k)
            )
            btn.pack(side="right", padx=12, pady=10)

    def _page_owner(self):
        f = self.page_frame
        ctk.CTkLabel(f, text="👑 Owner Panel", font=("Segoe UI", 24, "bold"),
                     text_color=self.theme_colors["gold"]).pack(pady=(20, 10), padx=20, anchor="w")

        info = ctk.CTkFrame(f, fg_color=self.theme_colors["bg_card"], corner_radius=12)
        info.pack(pady=10, padx=40, fill="x")
        ctk.CTkLabel(info, text="🔑 Owner Mode Enabled — All Features Unlocked",
                     font=("Segoe UI", 12, "bold"), text_color=self.theme_colors["gold"]).pack(pady=12, padx=20)

        ctk.CTkLabel(f, text="Key Management", font=("Segoe UI", 14, "bold"),
                     text_color=self.theme_colors["white"]).pack(pady=(20, 5), padx=20, anchor="w")

        btn_gen = ctk.CTkButton(f, text="Generate Pro Keys", fg_color=self.theme_colors["blue_dim"],
                                hover_color=self.theme_colors["blue_neon"], height=40, width=200,
                                command=lambda: messagebox.showinfo("Keys", "Run keygen.py in the keys folder to generate new Pro keys."))
        btn_gen.pack(pady=5, padx=20)

    def _page_themes(self):
        f = self.page_frame
        ctk.CTkLabel(f, text="🎨 Themes", font=("Segoe UI", 24, "bold"),
                     text_color=self.theme_colors["blue_neon"]).pack(pady=(20, 10), padx=20, anchor="w")

        for theme_name in THEMES.keys():
            btn = ctk.CTkButton(
                f, text=f"Apply {theme_name.title()} Theme",
                fg_color=self.theme_colors["blue_dim"],
                hover_color=self.theme_colors["blue_neon"],
                height=40, width=200,
                command=lambda t=theme_name: self._apply_theme(t)
            )
            btn.pack(pady=5, padx=20)

    def _apply_theme(self, theme_name):
        self.current_theme = theme_name
        self.theme_colors = THEMES[theme_name]
        messagebox.showinfo("Theme", f"{theme_name.title()} theme applied! Restart the app to see changes.")

    def _page_about(self):
        f = self.page_frame
        if self.logo_img:
            tk.Label(f, image=self.logo_img, bg=self.theme_colors["bg_dark"]).pack(pady=(20, 8))
        ctk.CTkLabel(f, text="ApexTweak v2.0", font=("Segoe UI", 22, "bold"),
                     text_color=self.theme_colors["blue_neon"]).pack()
        ctk.CTkLabel(f, text="Professional PC Performance Optimizer",
                     font=("Segoe UI", 12), text_color=self.theme_colors["gray"]).pack(pady=4)
        ctk.CTkLabel(f, text="© 2025 ApexTweak. All rights reserved.",
                     font=("Segoe UI", 10), text_color=self.theme_colors["gray"]).pack(pady=2)

    def _run_tweak(self, key):
        def task():
            success, msg = apply_tweak(key)
            messagebox.showinfo("ApexTweak", f"{'✅' if success else '❌'} {msg}")
        threading.Thread(target=task, daemon=True).start()

    def _start_stats_loop(self):
        def update():
            try:
                cpu = psutil.cpu_percent(interval=None)
                ram = psutil.virtual_memory().percent
                self.cpu_lbl.configure(text=f"CPU: {cpu:.0f}%")
                self.ram_lbl.configure(text=f"RAM: {ram:.0f}%")
            except Exception:
                pass
            self.after(2000, update)
        update()

# ─── Entry Point ──────────────────────────────────────────────────────────────
if __name__ == "__main__":
    # Auto-enable owner mode on first run
    if not is_owner():
        enable_owner_mode()
    
    app = ApexTweakV2()
    app.mainloop()
