"""
ApexTweak Pro Key Generator v2.0
Generate unlimited Pro license keys
"""

import random
import string

def generate_key():
    """Generate a single Pro license key in format: APEX-XXXX-XXXX-XXXX-XXXX"""
    parts = []
    for _ in range(4):
        part = ''.join(random.choices(string.ascii_uppercase + string.digits, k=4))
        parts.append(part)
    return f"APEX-{'-'.join(parts)}"

def main():
    print("\n" + "="*50)
    print("ApexTweak v2.0 — Pro Key Generator")
    print("="*50 + "\n")
    
    try:
        num_keys = int(input("How many Pro keys do you want to generate? "))
        if num_keys <= 0:
            print("❌ Please enter a positive number.")
            return
        
        keys = [generate_key() for _ in range(num_keys)]
        
        print(f"\n✅ Generated {num_keys} Pro keys:\n")
        for i, key in enumerate(keys, 1):
            print(f"{i:2d}. {key}")
        
        # Save to file
        with open("valid_keys.txt", "a") as f:
            for key in keys:
                f.write(key + "\n")
        
        print(f"\n✅ Keys saved to valid_keys.txt")
        print("="*50 + "\n")
    
    except ValueError:
        print("❌ Please enter a valid number.")

if __name__ == "__main__":
    main()
