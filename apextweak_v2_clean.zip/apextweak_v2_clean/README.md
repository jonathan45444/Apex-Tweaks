# ApexTweak v2.0 — Professional PC Performance Optimizer

Welcome to ApexTweak v2.0! This is your complete PC optimization toolkit with 30+ professional tweaks.

## 📦 What's Inside

```
apextweak_v2_clean/
├── app/
│   ├── apextweak_v2.py          ← Main app code
│   ├── apextweak_v2.spec        ← Build instructions for PyInstaller
│   ├── logo.png                 ← ApexTweak logo
│   └── dist/                    ← (After building) Your EXE goes here
├── keys/
│   ├── keygen.py                ← Generate Pro license keys
│   └── valid_keys.txt           ← List of valid Pro keys
├── BUILD_INSTRUCTIONS.md        ← Step-by-step build guide
└── README.md                    ← This file
```

## 🚀 Quick Start

1. **Install Python** — https://www.python.org/downloads/
2. **Install libraries** — `pip install customtkinter pillow psutil pyinstaller`
3. **Build the app** — `pyinstaller apextweak_v2.spec` (in the app folder)
4. **Run the app** — Right-click `dist/ApexTweak.exe` → Run as Administrator
5. **Generate keys** — Run `python keygen.py` in the keys folder

**Full instructions:** See `BUILD_INSTRUCTIONS.md`

## ✨ Features

- **30+ Tweaks** across 6 categories
- **Owner Mode** (automatically enabled for you)
- **4 Themes** — Dark, Neon, Matrix, Cyberpunk
- **Live Monitoring** — Real-time CPU & RAM stats
- **Professional Key System** — Sell Pro licenses
- **Admin Controls** — Manage everything from Owner Panel

## 🎮 Tweak Categories

| Category | Count | Examples |
|----------|-------|----------|
| 🚀 FPS Boost | 7 | GPU Scheduling, Core Parking, Game Priority |
| ⚙️ CPU & Process | 9 | Disable Telemetry, Superfetch, Background Apps |
| 🌐 Network | 5 | Low Ping, TCP Optimizer, RSS |
| 🧹 Cleaner | 4 | Temp Files, DNS, Prefetch, Event Logs |
| 🖱️ Input & Mouse | 2 | Zero Delay, Disable Acceleration |
| 🔧 Advanced | 5 | Power Plans, USB, File Cache, SSD |

## 👑 Owner Mode

You automatically have Owner Mode enabled! This means:
- ✅ All 30+ tweaks unlocked
- ✅ Access to Owner Panel
- ✅ Key management controls
- ✅ Theme switching
- ✅ Full admin access

## 🔑 Pro Keys

Generate unlimited Pro keys for selling:

```bash
cd keys
python keygen.py
# Enter how many keys you want
# Keys are saved to valid_keys.txt
```

Key format: `APEX-XXXX-XXXX-XXXX-XXXX`

## 🎨 Themes

Switch between 4 beautiful themes:
- **Dark** — Classic blue/black with snow
- **Neon** — Vibrant pink/purple neon
- **Matrix** — Green terminal aesthetic
- **Cyberpunk** — Cyan/pink futuristic

## 📊 System Requirements

- **OS:** Windows 10 or 11
- **Python:** 3.10 or newer (for building)
- **Admin Rights:** Required to run tweaks
- **RAM:** 2GB minimum

## ⚠️ Important Notes

1. **Run as Administrator** — Required for tweaks to work
2. **Backup First** — Some tweaks modify system settings
3. **Test First** — Test on your PC before distributing
4. **Keep Keys Safe** — Store `valid_keys.txt` securely

## 🛠️ Building for Distribution

When you're ready to share:

1. Build the EXE (see BUILD_INSTRUCTIONS.md)
2. Copy the `keys` folder into the `dist` folder
3. Zip the entire `dist` folder
4. Share with users

Users just need to:
1. Extract the ZIP
2. Right-click `ApexTweak.exe` → Run as Administrator
3. Enter a Pro key if they have one

## 📝 Next Steps

- [ ] Build the EXE
- [ ] Test all tweaks
- [ ] Generate Pro keys
- [ ] Build the website (we'll do this together)
- [ ] Set up Stripe payments
- [ ] Launch!

## 🆘 Need Help?

See `BUILD_INSTRUCTIONS.md` for detailed troubleshooting.

---

**ApexTweak v2.0 — Professional PC Performance Optimizer**  
Built with ❄️ Blue/Black Snow Theme | Owner Mode | 30+ Tweaks | 4 Themes
