# ApexTweak v2.0 — Build Instructions

## What's New in v2.0

✨ **30+ Professional Tweaks** — FPS, CPU, Network, Cleaning, Input, Advanced  
👑 **Owner Mode** — Automatically enabled for you (all features unlocked)  
🎨 **4 Themes** — Dark, Neon, Matrix, Cyberpunk  
📊 **Live Monitoring** — Real-time CPU & RAM stats  
🔑 **Professional Key System** — For selling Pro licenses  
🚀 **Advanced Features** — Rollback, profiles, auto-apply  

---

## Step 1: Install Python

1. Go to: https://www.python.org/downloads/
2. Download Python 3.10 or newer
3. **IMPORTANT:** Check "Add Python to PATH" during installation
4. Click Install

**Verify it worked:**
- Press `Windows Key + R`
- Type `cmd`
- Type: `python --version`
- You should see a version number

---

## Step 2: Install Required Libraries

1. Open Command Prompt
2. Copy and paste this:
```
pip install customtkinter pillow psutil pyinstaller
```
3. Press Enter and wait for it to finish

---

## Step 3: Build the EXE

1. Open Command Prompt
2. Navigate to the app folder:
```
cd C:\Users\YourUsername\Downloads\apextweak_v2_clean\app
```

3. Build the app:
```
pyinstaller apextweak_v2.spec
```

4. Wait 2-3 minutes for it to finish. You'll see "Build complete!" when done.

---

## Step 4: Test the App

1. Go to: `C:\Users\YourUsername\Downloads\apextweak_v2_clean\app\dist`
2. Right-click `ApexTweak.exe`
3. Click **"Run as Administrator"**
4. The app should open with your logo and blue/black snow theme

---

## Step 5: Generate Pro Keys

1. Open Command Prompt
2. Navigate to the keys folder:
```
cd C:\Users\YourUsername\Downloads\apextweak_v2_clean\keys
```

3. Run the key generator:
```
python keygen.py
```

4. Enter how many keys you want (e.g., `10`)
5. Keys will be printed and saved to `valid_keys.txt`

---

## Step 6: Distribute Your App

When you're ready to give the app to others:

1. Go to: `C:\Users\YourUsername\Downloads\apextweak_v2_clean\app\dist`
2. You'll see:
   - `ApexTweak.exe` (the app)
   - `_internal` folder (required libraries)

3. Copy the `keys` folder from the main package into `dist` folder

4. Your distribution folder should look like:
```
ApexTweak/
├── ApexTweak.exe
├── _internal/
└── keys/
    └── valid_keys.txt
```

5. Zip this folder and share it!

---

## Features Overview

### 🏠 Dashboard
- Overview of all features
- Quick stats

### 🚀 FPS Boost (7 tweaks)
- Disable Xbox Game DVR
- GPU Hardware Scheduling
- Ultimate Performance Plan
- Disable CPU Core Parking
- Boost Game Priority
- Disable Fullscreen Optimizations
- Increase GPU Memory

### ⚙️ CPU & Process (9 tweaks)
- Disable Telemetry
- Disable Search Indexing
- Disable Superfetch
- Disable Background Apps
- Optimize RAM
- Remove Startup Delay
- Disable Animations
- Disable Transparency
- Disable Tips & Notifications

### 🌐 Network (5 tweaks)
- Disable Nagle's Algorithm (lower ping)
- Full Network Optimization
- TCP Stack Optimizer
- Disable IPv6
- Enable RSS

### 🧹 Cleaner (4 tweaks)
- Clear Temp Files
- Flush DNS Cache
- Clear Prefetch
- Clear Event Logs

### 🖱️ Input & Mouse (2 tweaks)
- Zero Delay Mouse (raw 1:1 input)
- Disable Mouse Acceleration

### 🔧 Advanced (5 tweaks)
- High Performance Plan
- Disable USB Selective Suspend
- Increase File Cache
- Disable Fast Startup
- Optimize SSD

### 👑 Owner Panel
- Key management info
- Admin controls

### 🎨 Themes
- Dark (default)
- Neon
- Matrix
- Cyberpunk

---

## Troubleshooting

**"Python is not recognized"**
- Uninstall Python and reinstall, checking "Add Python to PATH"

**"No module named 'customtkinter'"**
- Run: `pip install customtkinter pillow psutil pyinstaller` again

**"App won't open"**
- Right-click EXE → "Run as Administrator"

**"Tweaks aren't working"**
- Make sure you're running as Administrator

**"Can't find the app folder"**
- Search your computer for "apextweak_v2_clean"

---

## Next Steps

1. ✅ Build the EXE
2. ✅ Test it on your PC
3. ✅ Generate some Pro keys
4. ⏭️ We'll work on the website to sell Pro keys
5. ⏭️ Set up payment processing (Stripe)
6. ⏭️ Auto-email keys to customers

---

**You're all set! Let me know when you've built it and tested it.** 🚀
